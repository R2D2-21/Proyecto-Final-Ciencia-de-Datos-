# 🏠 Estimador de Precios de Propiedades

Aplicación web para estimar precios de propiedades usando Machine Learning (Random Forest + K-Means clustering).

## ✨ Funcionalidades

- **Predictor de precios** — ingresa características y obtén un precio estimado con rango de confianza
- **Perfil de inversión** — clustering que clasifica la propiedad en Perfil Familiar, Ejecutivo o Inversión Económica
- **Dashboard EDA** — importancia de variables, comparación de modelos (Linear Regression vs Random Forest)
- **Reporte crítico** — hallazgos, limitaciones y análisis del modelo

## 🚀 Inicio rápido en GitHub Codespaces

### Opción A — Botón de Codespace (recomendado)

1. Click en **Code → Codespaces → Create codespace on main**
2. Espera ~2 minutos mientras el setup automático instala todo
3. Ejecuta el servidor:

```bash
pnpm dev
```

4. Abre el puerto **3000** en la pestaña *Ports* (se abrirá automáticamente)

---

### Opción B — Setup manual

```bash
# 1. Instalar pnpm
npm install -g pnpm

# 2. Instalar dependencias Node
pnpm install

# 3. Instalar dependencias Python (para los modelos ML)
pip install joblib scikit-learn numpy

# 4. Copiar variables de entorno
cp .env.example .env

# 5. Arrancar
pnpm dev
```

## 🏗️ Stack tecnológico

| Capa | Tecnología |
|------|-----------|
| Frontend | React 19, TypeScript, Tailwind CSS 4, shadcn/ui |
| Backend | Node.js, Express, tRPC |
| ML | Python 3, scikit-learn, joblib |
| ORM | Drizzle (MySQL — opcional) |
| Build | Vite 7, pnpm |

## 📁 Estructura del proyecto

```
house-price-estimator/
├── client/src/          # Frontend React
│   ├── pages/           # Home, Predictor, Dashboard, Report
│   ├── components/      # Componentes reutilizables
│   └── lib/             # tRPC client, utils
├── server/              # Backend Express + tRPC
│   ├── routers.ts       # Endpoints ML (predict, cluster, metrics)
│   ├── predict_model.py # Script Python para inferencia
│   └── ml_models.py     # Módulo de modelos ML
├── *.joblib             # Modelos pre-entrenados
└── .devcontainer/       # Configuración GitHub Codespaces
```

## 🤖 Modelos ML

Los modelos están pre-entrenados y listos para usar:

| Archivo | Descripción |
|---------|-------------|
| `rf_model.joblib` | Random Forest (R² = 0.876) |
| `kmeans_model.joblib` | K-Means clustering (3 perfiles) |
| `scaler.joblib` | StandardScaler para normalización |
| `features_list.joblib` | Lista de features en orden correcto |

## ⚙️ Variables de entorno

El archivo `.env.example` documenta todas las variables. Para las funciones ML **no se necesita base de datos ni OAuth** — solo `PORT` y `NODE_ENV`.

La base de datos MySQL es opcional y solo se usa para autenticación de usuarios.
