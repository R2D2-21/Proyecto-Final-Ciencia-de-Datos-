#!/bin/bash
set -e

echo "================================================"
echo "  House Price Estimator — Codespaces Setup"
echo "================================================"

# ── 1. Node dependencies ────────────────────────────
echo ""
echo "📦 Installing Node dependencies..."
npm install -g pnpm
pnpm install

# ── 2. Python dependencies ──────────────────────────
echo ""
echo "🐍 Installing Python dependencies..."
pip install --upgrade pip --quiet
pip install joblib scikit-learn numpy --quiet

# ── 3. Copy .env if it doesn't exist ───────────────
if [ ! -f .env ]; then
  echo ""
  echo "⚙️  Creating .env from template..."
  cp .env.example .env
  echo "   ✅ .env created — edit it to add your secrets if needed."
fi

# ── 4. SQLite DB setup (no DATABASE_URL needed) ─────
echo ""
echo "🗄️  Skipping DB migration (SQLite / no DATABASE_URL required for ML features)"

echo ""
echo "================================================"
echo "  ✅ Setup complete!"
echo ""
echo "  Run the app:"
echo "    pnpm dev"
echo ""
echo "  Then open the forwarded port 3000."
echo "================================================"
