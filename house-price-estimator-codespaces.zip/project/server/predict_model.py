"""
Script para realizar predicciones usando modelos pre-entrenados.
Se ejecuta como un proceso separado desde Node.js.
"""
import sys
import json
import os
import numpy as np

try:
    import joblib

    # Ruta dinámica: funciona en cualquier entorno (Manus, Codespaces, local)
    BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

    rf_model    = joblib.load(os.path.join(BASE_DIR, 'rf_model.joblib'))
    kmeans_model = joblib.load(os.path.join(BASE_DIR, 'kmeans_model.joblib'))
    scaler      = joblib.load(os.path.join(BASE_DIR, 'scaler.joblib'))

    action = sys.argv[1]

    args = [float(x) for x in sys.argv[2:10]]
    features = np.array([args])

    if action == 'predict':
        prediction = rf_model.predict(features)[0]
        rmse = 4549732.83
        confidence_range = rmse * 0.5

        result = {
            'estimated_price': float(prediction),
            'lower_bound':     float(prediction - confidence_range),
            'upper_bound':     float(prediction + confidence_range),
            'confidence':      'Alta' if args[0] > 500 else 'Media'
        }
        print(json.dumps(result))

    elif action == 'cluster':
        features_scaled = scaler.transform(features)
        cluster = int(kmeans_model.predict(features_scaled)[0])

        cluster_profiles = {
            0: 'Perfil Ejecutivo',
            1: 'Inversión Económica',
            2: 'Perfil Familiar'
        }
        descriptions = {
            0: 'Propiedades de alto valor con amplias áreas y múltiples servicios, dirigidas a ejecutivos y profesionales.',
            1: 'Propiedades compactas y económicas, ideales para inversión o primera vivienda.',
            2: 'Propiedades medianas con buen balance de espacio y comodidades, perfectas para familias.'
        }

        result = {
            'cluster':     cluster,
            'profile':     cluster_profiles.get(cluster, 'Desconocido'),
            'description': descriptions.get(cluster, 'Perfil no identificado')
        }
        print(json.dumps(result))

    else:
        print(json.dumps({'error': f'Acción desconocida: {action}'}), file=sys.stderr)
        sys.exit(1)

except Exception as e:
    print(json.dumps({'error': str(e)}), file=sys.stderr)
    sys.exit(1)
