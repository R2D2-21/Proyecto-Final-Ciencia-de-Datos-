import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import { z } from "zod";
import { spawn } from "child_process";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Helper para ejecutar predicciones con Python
function executePrediction(
  action: string,
  carpet_area: number,
  bathroom_num: number,
  balcony: number,
  parking_count: number,
  bhk: number,
  bath_per_bhk: number,
  luxury_score: number,
  relative_floor: number
): Promise<any> {
  return new Promise((resolve, reject) => {
    const python = spawn("python3", [
      path.join(__dirname, "../predict_model.py"),
      action,
      carpet_area.toString(),
      bathroom_num.toString(),
      balcony.toString(),
      parking_count.toString(),
      bhk.toString(),
      bath_per_bhk.toString(),
      luxury_score.toString(),
      relative_floor.toString(),
    ]);

    let output = "";
    let error = "";

    python.stdout.on("data", (data) => {
      output += data.toString();
    });

    python.stderr.on("data", (data) => {
      error += data.toString();
    });

    python.on("close", (code) => {
      if (code !== 0 || error) {
        reject(new Error(`Prediction error: ${error || "Unknown error"}`));
      } else {
        try {
          resolve(JSON.parse(output.trim()));
        } catch (e) {
          reject(new Error(`Failed to parse prediction output: ${output}`));
        }
      }
    });
  });
}

export const appRouter = router({
  // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  // ML Prediction Router
  ml: router({
    predict: publicProcedure
      .input(
        z.object({
          carpet_area: z.number().positive(),
          bathroom_num: z.number().nonnegative(),
          balcony: z.number().nonnegative(),
          parking_count: z.number().nonnegative(),
          bhk: z.number().positive(),
          bath_per_bhk: z.number().nonnegative(),
          luxury_score: z.number().min(0).max(5),
          relative_floor: z.number().min(0).max(1),
        })
      )
      .mutation(async ({ input }) => {
        try {
          return await executePrediction(
            "predict",
            input.carpet_area,
            input.bathroom_num,
            input.balcony,
            input.parking_count,
            input.bhk,
            input.bath_per_bhk,
            input.luxury_score,
            input.relative_floor
          );
        } catch (error) {
          throw new Error(`Prediction failed: ${error}`);
        }
      }),

    clusterProfile: publicProcedure
      .input(
        z.object({
          carpet_area: z.number().positive(),
          bathroom_num: z.number().nonnegative(),
          balcony: z.number().nonnegative(),
          parking_count: z.number().nonnegative(),
          bhk: z.number().positive(),
          bath_per_bhk: z.number().nonnegative(),
          luxury_score: z.number().min(0).max(5),
          relative_floor: z.number().min(0).max(1),
        })
      )
      .query(async ({ input }) => {
        try {
          return await executePrediction(
            "cluster",
            input.carpet_area,
            input.bathroom_num,
            input.balcony,
            input.parking_count,
            input.bhk,
            input.bath_per_bhk,
            input.luxury_score,
            input.relative_floor
          );
        } catch (error) {
          throw new Error(`Cluster analysis failed: ${error}`);
        }
      }),

    modelMetrics: publicProcedure.query(async () => {
      return {
        linear_regression: {
          MAE: 5429235.89,
          RMSE: 8040267.42,
          R2: 0.6138,
        },
        random_forest: {
          MAE: 1981372.58,
          RMSE: 4549732.83,
          R2: 0.8763,
        },
      };
    }),

    featureImportance: publicProcedure.query(async () => {
      return {
        Carpet_Area_Num: 0.723465,
        Bathroom_Num: 0.081219,
        Relative_Floor: 0.06484,
        Parking_Count: 0.046256,
        Balcony: 0.03828,
        Bath_per_BHK: 0.03417,
        BHK: 0.008867,
        Luxury_Score: 0.002903,
      };
    }),
  }),
});

export type AppRouter = typeof appRouter;
