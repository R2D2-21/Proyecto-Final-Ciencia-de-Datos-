"""
Módulo para cargar y utilizar modelos de Machine Learning entrenados.
Proporciona funciones para predicción de precios y análisis de clustering.
"""

import joblib
import numpy as np
import os
from pathlib import Path

# Obtener la ruta del directorio actual
BASE_DIR = Path(__file__).parent.parent

# Cargar modelos
rf_model = joblib.load(BASE_DIR / 'rf_model.joblib')
kmeans_model = joblib.load(BASE_DIR / 'kmeans_model.joblib')
scaler = joblib.load(BASE_DIR / 'scaler.joblib')
features_list = joblib.load(BASE_DIR / 'features_list.joblib')

# Métricas de los modelos (calculadas durante el entrenamiento)
MODEL_METRICS = {
    'linear_regression': {
        'MAE': 5429235.89,
        'RMSE': 8040267.42,
        'R2': 0.6138
    },
    'random_forest': {
        'MAE': 1981372.58,
        'RMSE': 4549732.83,
        'R2': 0.8763
    }
}

# Importancia de variables
FEATURE_IMPORTANCE = {
    'Carpet_Area_Num': 0.723465,
    'Bathroom_Num': 0.081219,
    'Relative_Floor': 0.064840,
    'Parking_Count': 0.046256,
    'Balcony': 0.038280,
    'Bath_per_BHK': 0.034170,
    'BHK': 0.008867,
    'Luxury_Score': 0.002903
}

# Mapeo de clusters a nombres de perfiles
CLUSTER_PROFILES = {
    0: 'Perfil Ejecutivo',
    1: 'Inversión Económica',
    2: 'Perfil Familiar'
}

def predict_price(carpet_area, bathroom_num, balcony, parking_count, bhk, bath_per_bhk, luxury_score, relative_floor):
    """
    Predice el precio de una propiedad usando el modelo Random Forest.
    
    Args:
        carpet_area (float): Área de la propiedad en sqft
        bathroom_num (float): Número de baños
        balcony (float): Número de balcones
        parking_count (float): Número de estacionamientos
        bhk (float): Número de habitaciones
        bath_per_bhk (float): Ratio de baños por habitación
        luxury_score (float): Puntuación de lujo (0-5)
        relative_floor (float): Piso relativo (0-1)
    
    Returns:
        dict: Predicción con precio estimado y rango de confianza
    """
    try:
        # Crear array de características en el orden correcto
        features = np.array([[
            carpet_area,
            bathroom_num,
            balcony,
            parking_count,
            bhk,
            bath_per_bhk,
            luxury_score,
            relative_floor
        ]])
        
        # Realizar predicción
        prediction = rf_model.predict(features)[0]
        
        # Calcular rango de confianza (±20% basado en RMSE del modelo)
        rmse = MODEL_METRICS['random_forest']['RMSE']
        confidence_range = rmse * 0.5  # Usar 50% del RMSE como rango
        
        return {
            'estimated_price': float(prediction),
            'lower_bound': float(prediction - confidence_range),
            'upper_bound': float(prediction + confidence_range),
            'confidence': 'Alta' if carpet_area > 500 else 'Media'
        }
    except Exception as e:
        raise ValueError(f"Error en predicción: {str(e)}")

def get_cluster_profile(carpet_area, bathroom_num, balcony, parking_count, bhk, bath_per_bhk, luxury_score, relative_floor):
    """
    Determina el perfil de estilo de vida (cluster) de una propiedad.
    
    Args:
        (mismos parámetros que predict_price)
    
    Returns:
        dict: Información del cluster y perfil
    """
    try:
        features = np.array([[
            carpet_area,
            bathroom_num,
            balcony,
            parking_count,
            bhk,
            bath_per_bhk,
            luxury_score,
            relative_floor
        ]])
        
        # Escalar características
        features_scaled = scaler.transform(features)
        
        # Predecir cluster
        cluster = kmeans_model.predict(features_scaled)[0]
        profile_name = CLUSTER_PROFILES.get(cluster, 'Desconocido')
        
        return {
            'cluster': int(cluster),
            'profile': profile_name,
            'description': get_profile_description(cluster)
        }
    except Exception as e:
        raise ValueError(f"Error en clustering: {str(e)}")

def get_profile_description(cluster):
    """Retorna descripción del perfil según el cluster."""
    descriptions = {
        0: 'Propiedades de alto valor con amplias áreas y múltiples servicios, dirigidas a ejecutivos y profesionales.',
        1: 'Propiedades compactas y económicas, ideales para inversión o primera vivienda.',
        2: 'Propiedades medianas con buen balance de espacio y comodidades, perfectas para familias.'
    }
    return descriptions.get(cluster, 'Perfil no identificado')

def get_model_metrics():
    """Retorna las métricas de evaluación de ambos modelos."""
    return MODEL_METRICS

def get_feature_importance():
    """Retorna la importancia de cada variable."""
    return FEATURE_IMPORTANCE
