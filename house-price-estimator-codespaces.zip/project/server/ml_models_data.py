"""
Datos precalculados de modelos ML para evitar dependencias de joblib en tiempo de ejecución.
"""

# Métricas de los modelos (calculadas durante el entrenamiento)
MODEL_METRICS = {
    'linear_regression': {
        'MAE': 5429235.89,
        'RMSE': 8040267.42,
        'R2': 0.6138
    },
    'random_forest': {
        'MAE': 1981372.58,
        'RMSE': 4549732.83,
        'R2': 0.8763
    }
}

# Importancia de variables
FEATURE_IMPORTANCE = {
    'Carpet_Area_Num': 0.723465,
    'Bathroom_Num': 0.081219,
    'Relative_Floor': 0.064840,
    'Parking_Count': 0.046256,
    'Balcony': 0.038280,
    'Bath_per_BHK': 0.034170,
    'BHK': 0.008867,
    'Luxury_Score': 0.002903
}

# Mapeo de clusters a nombres de perfiles
CLUSTER_PROFILES = {
    0: 'Perfil Ejecutivo',
    1: 'Inversión Económica',
    2: 'Perfil Familiar'
}

# Características promedio por cluster (para análisis)
CLUSTER_STATS = {
    0: {
        'name': 'Perfil Ejecutivo',
        'avg_area': 1728.83,
        'avg_bathrooms': 3.33,
        'avg_price': 21373700,
        'description': 'Propiedades de alto valor con amplias áreas y múltiples servicios, dirigidas a ejecutivos y profesionales.'
    },
    1: {
        'name': 'Inversión Económica',
        'avg_area': 792.21,
        'avg_bathrooms': 1.93,
        'avg_price': 6702813,
        'description': 'Propiedades compactas y económicas, ideales para inversión o primera vivienda.'
    },
    2: {
        'name': 'Perfil Familiar',
        'avg_area': 764.07,
        'avg_bathrooms': 2.04,
        'avg_price': 4845347,
        'description': 'Propiedades medianas con buen balance de espacio y comodidades, perfectas para familias.'
    }
}

def get_profile_description(cluster):
    """Retorna descripción del perfil según el cluster."""
    if cluster in CLUSTER_STATS:
        return CLUSTER_STATS[cluster]['description']
    return 'Perfil no identificado'
