import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Loader2, AlertCircle } from "lucide-react";
import { trpc } from "@/lib/trpc";

export default function Predictor() {
  const [formData, setFormData] = useState({
    carpet_area: 800,
    bathroom_num: 2,
    balcony: 1,
    parking_count: 1,
    bhk: 2,
    bath_per_bhk: 1,
    luxury_score: 2,
    relative_floor: 0.5,
  });

  const [prediction, setPrediction] = useState<any>(null);
  const [clusterInfo, setClusterInfo] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);

  const predictMutation = trpc.ml.predict.useMutation();
  const clusterMutation = trpc.ml.clusterProfile.useQuery(formData, {
    enabled: false,
  });

  const handlePredict = async () => {
    setError(null);
    try {
      const result = await predictMutation.mutateAsync(formData);
      setPrediction(result);

      // Obtener perfil de cluster
      const clusterResult = await clusterMutation.refetch();
      if (clusterResult.data) {
        setClusterInfo(clusterResult.data);
      }
    } catch (err: any) {
      setError(err.message || "Error en la predicción");
    }
  };

  const handleInputChange = (field: string, value: number) => {
    setFormData((prev) => ({
      ...prev,
      [field]: value,
    }));
  };

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat("es-AR", {
      style: "currency",
      currency: "ARS",
      minimumFractionDigits: 0,
    }).format(price);
  };

  return (
    <div className="min-h-screen section-spacing bg-gradient-to-br from-background via-background to-accent/5">
      <div className="container">
        <div className="max-w-4xl mx-auto">
          {/* Header */}
          <div className="text-center mb-12">
            <h1 className="text-4xl md:text-5xl font-bold mb-4">
              Estimador de Precios
            </h1>
            <p className="text-lg text-muted-foreground">
              Ingresa las características de la propiedad para obtener una estimación de precio basada en Machine Learning
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            {/* Form */}
            <div className="md:col-span-2">
              <Card className="card-elegant">
                <div className="space-y-6">
                  {/* Carpet Area */}
                  <div className="space-y-3">
                    <Label className="text-base font-semibold">
                      Área (sqft): {formData.carpet_area}
                    </Label>
                    <Slider
                      value={[formData.carpet_area]}
                      onValueChange={(val) =>
                        handleInputChange("carpet_area", val[0])
                      }
                      min={200}
                      max={3000}
                      step={50}
                      className="w-full"
                    />
                  </div>

                  {/* Bathrooms */}
                  <div className="space-y-3">
                    <Label className="text-base font-semibold">
                      Baños: {formData.bathroom_num}
                    </Label>
                    <Slider
                      value={[formData.bathroom_num]}
                      onValueChange={(val) =>
                        handleInputChange("bathroom_num", val[0])
                      }
                      min={1}
                      max={6}
                      step={1}
                      className="w-full"
                    />
                  </div>

                  {/* Balconies */}
                  <div className="space-y-3">
                    <Label className="text-base font-semibold">
                      Balcones: {formData.balcony}
                    </Label>
                    <Slider
                      value={[formData.balcony]}
                      onValueChange={(val) =>
                        handleInputChange("balcony", val[0])
                      }
                      min={0}
                      max={5}
                      step={1}
                      className="w-full"
                    />
                  </div>

                  {/* Parking */}
                  <div className="space-y-3">
                    <Label className="text-base font-semibold">
                      Estacionamientos: {formData.parking_count}
                    </Label>
                    <Slider
                      value={[formData.parking_count]}
                      onValueChange={(val) =>
                        handleInputChange("parking_count", val[0])
                      }
                      min={0}
                      max={5}
                      step={1}
                      className="w-full"
                    />
                  </div>

                  {/* BHK */}
                  <div className="space-y-3">
                    <Label className="text-base font-semibold">
                      Habitaciones (BHK): {formData.bhk}
                    </Label>
                    <Slider
                      value={[formData.bhk]}
                      onValueChange={(val) =>
                        handleInputChange("bhk", val[0])
                      }
                      min={1}
                      max={6}
                      step={1}
                      className="w-full"
                    />
                  </div>

                  {/* Luxury Score */}
                  <div className="space-y-3">
                    <Label className="text-base font-semibold">
                      Puntuación de Lujo: {formData.luxury_score}
                    </Label>
                    <Slider
                      value={[formData.luxury_score]}
                      onValueChange={(val) =>
                        handleInputChange("luxury_score", val[0])
                      }
                      min={0}
                      max={5}
                      step={1}
                      className="w-full"
                    />
                  </div>

                  {/* Relative Floor */}
                  <div className="space-y-3">
                    <Label className="text-base font-semibold">
                      Piso Relativo: {(formData.relative_floor * 100).toFixed(0)}%
                    </Label>
                    <Slider
                      value={[formData.relative_floor]}
                      onValueChange={(val) =>
                        handleInputChange("relative_floor", val[0])
                      }
                      min={0}
                      max={1}
                      step={0.1}
                      className="w-full"
                    />
                  </div>

                  {/* Error Message */}
                  {error && (
                    <div className="bg-destructive/10 border border-destructive/30 rounded-lg p-4 flex items-start gap-3">
                      <AlertCircle className="w-5 h-5 text-destructive flex-shrink-0 mt-0.5" />
                      <p className="text-sm text-destructive">{error}</p>
                    </div>
                  )}

                  {/* Submit Button */}
                  <Button
                    onClick={handlePredict}
                    disabled={predictMutation.isPending}
                    className="btn-primary w-full"
                  >
                    {predictMutation.isPending ? (
                      <>
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        Estimando...
                      </>
                    ) : (
                      "Estimar Precio"
                    )}
                  </Button>
                </div>
              </Card>
            </div>

            {/* Results */}
            <div className="md:col-span-1">
              {prediction ? (
                <div className="space-y-4">
                  {/* Price Card */}
                  <Card className="card-elegant bg-gradient-to-br from-accent/5 to-orange-500/5 border-accent/20">
                    <div className="space-y-2">
                      <p className="text-sm text-muted-foreground font-medium">
                        Precio Estimado
                      </p>
                      <p className="text-3xl font-bold text-accent">
                        {formatPrice(prediction.estimated_price)}
                      </p>
                      <div className="pt-4 space-y-2 border-t border-border">
                        <div className="flex justify-between text-sm">
                          <span className="text-muted-foreground">Mínimo:</span>
                          <span className="font-semibold">
                            {formatPrice(prediction.lower_bound)}
                          </span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span className="text-muted-foreground">Máximo:</span>
                          <span className="font-semibold">
                            {formatPrice(prediction.upper_bound)}
                          </span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span className="text-muted-foreground">Confianza:</span>
                          <span className="font-semibold text-accent">
                            {prediction.confidence}
                          </span>
                        </div>
                      </div>
                    </div>
                  </Card>

                  {/* Cluster Profile */}
                  {clusterInfo && (
                    <Card className="card-elegant">
                      <div className="space-y-3">
                        <p className="text-sm text-muted-foreground font-medium">
                          Perfil de Inversión
                        </p>
                        <p className="text-xl font-bold text-accent">
                          {clusterInfo.profile}
                        </p>
                        <p className="text-sm text-muted-foreground leading-relaxed">
                          {clusterInfo.description}
                        </p>
                      </div>
                    </Card>
                  )}
                </div>
              ) : (
                <Card className="card-elegant h-full flex items-center justify-center">
                  <div className="text-center">
                    <p className="text-muted-foreground">
                      Los resultados aparecerán aquí
                    </p>
                  </div>
                </Card>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
