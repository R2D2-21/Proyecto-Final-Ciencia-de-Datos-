import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { BarChart3, TrendingUp, Zap } from "lucide-react";

export default function Home() {
  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="section-spacing bg-gradient-to-br from-background via-background to-accent/5">
        <div className="container">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div className="animate-fade-in-up space-y-6">
              <div className="space-y-4">
                <h1 className="text-5xl md:text-6xl font-bold leading-tight">
                  Estima Precios de Propiedades con
                  <span className="text-gradient"> Inteligencia Artificial</span>
                </h1>
                <p className="text-xl text-muted-foreground leading-relaxed">
                  Utiliza modelos de Machine Learning avanzados para obtener predicciones precisas del valor de mercado de propiedades residenciales. Descubre perfiles de inversión y analiza tendencias del mercado inmobiliario.
                </p>
              </div>

              <div className="flex flex-col sm:flex-row gap-4 pt-4">
                <Link href="/predictor">
                  <a>
                    <Button className="btn-primary w-full sm:w-auto">
                      Comenzar Estimación
                    </Button>
                  </a>
                </Link>
                <Link href="/dashboard">
                  <a>
                    <Button variant="outline" className="w-full sm:w-auto">
                      Ver Análisis
                    </Button>
                  </a>
                </Link>
              </div>
            </div>

            {/* Visual Element */}
            <div className="hidden md:flex items-center justify-center">
              <div className="relative w-full h-96">
                <div className="absolute inset-0 bg-gradient-to-br from-accent/20 to-orange-500/20 rounded-3xl blur-3xl"></div>
                <div className="relative bg-card rounded-3xl p-8 border border-border shadow-lg">
                  <div className="space-y-4">
                    <div className="h-3 bg-accent/20 rounded-full w-3/4"></div>
                    <div className="h-3 bg-accent/30 rounded-full w-1/2"></div>
                    <div className="grid grid-cols-2 gap-4 pt-4">
                      <div className="bg-accent/10 rounded-lg p-4 text-center">
                        <div className="text-2xl font-bold text-accent">87.6%</div>
                        <div className="text-xs text-muted-foreground">Precisión R²</div>
                      </div>
                      <div className="bg-accent/10 rounded-lg p-4 text-center">
                        <div className="text-2xl font-bold text-accent">1.9M</div>
                        <div className="text-xs text-muted-foreground">MAE Promedio</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="section-spacing bg-card/50">
        <div className="container">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold mb-4">Características Principales</h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Herramientas avanzadas para análisis y predicción de precios inmobiliarios
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            {/* Feature 1 */}
            <Card className="card-elegant group hover:border-accent transition-colors">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center group-hover:bg-accent/20 transition-colors">
                  <TrendingUp className="w-6 h-6 text-accent" />
                </div>
                <div className="flex-1">
                  <h3 className="font-semibold text-lg mb-2">Predicción Precisa</h3>
                  <p className="text-sm text-muted-foreground">
                    Modelos Random Forest con 87.6% de precisión (R²) para estimaciones confiables
                  </p>
                </div>
              </div>
            </Card>

            {/* Feature 2 */}
            <Card className="card-elegant group hover:border-accent transition-colors">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center group-hover:bg-accent/20 transition-colors">
                  <BarChart3 className="w-6 h-6 text-accent" />
                </div>
                <div className="flex-1">
                  <h3 className="font-semibold text-lg mb-2">Análisis Detallado</h3>
                  <p className="text-sm text-muted-foreground">
                    Visualizaciones interactivas de correlaciones, importancia de variables y clustering
                  </p>
                </div>
              </div>
            </Card>

            {/* Feature 3 */}
            <Card className="card-elegant group hover:border-accent transition-colors">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center group-hover:bg-accent/20 transition-colors">
                  <Zap className="w-6 h-6 text-accent" />
                </div>
                <div className="flex-1">
                  <h3 className="font-semibold text-lg mb-2">Segmentación Inteligente</h3>
                  <p className="text-sm text-muted-foreground">
                    Identifica perfiles de inversión: Familiar, Ejecutivo e Inversión Económica
                  </p>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="section-spacing">
        <div className="container">
          <div className="bg-gradient-to-r from-accent to-orange-500 rounded-3xl p-12 md:p-16 text-white text-center">
            <h2 className="text-4xl font-bold mb-4">¿Listo para comenzar?</h2>
            <p className="text-lg opacity-90 mb-8 max-w-2xl mx-auto">
              Obtén una estimación de precio en segundos. Ingresa las características de la propiedad y descubre su valor de mercado.
            </p>
            <Link href="/predictor">
              <a>
                <Button className="bg-white text-accent hover:bg-white/90 px-8 py-3 text-lg font-semibold">
                  Estimar Precio Ahora
                </Button>
              </a>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
