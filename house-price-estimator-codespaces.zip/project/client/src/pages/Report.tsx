import { Card } from "@/components/ui/card";
import { AlertCircle, TrendingUp, Database } from "lucide-react";

export default function Report() {
  return (
    <div className="min-h-screen section-spacing bg-gradient-to-br from-background via-background to-accent/5">
      <div className="container max-w-4xl">
        {/* Header */}
        <div className="mb-12">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">
            Reporte de Análisis Crítico
          </h1>
          <p className="text-lg text-muted-foreground">
            Hallazgos principales, limitaciones del modelo y recomendaciones para mejora
          </p>
        </div>

        {/* Main Findings */}
        <Card className="card-elegant mb-6">
          <div className="space-y-6">
            <div>
              <h2 className="text-2xl font-bold mb-4 flex items-center gap-2">
                <TrendingUp className="w-6 h-6 text-accent" />
                Hallazgos Principales
              </h2>
              <div className="space-y-4 text-muted-foreground leading-relaxed">
                <p>
                  El análisis de correlaciones revela que el <strong>área de la propiedad (Carpet Area)</strong> es el factor más determinante en la predicción de precios, representando el 72.3% de la importancia total del modelo. Esta variable tiene una correlación extremadamente fuerte con el precio total, lo que sugiere que el mercado inmobiliario valúa principalmente el espacio disponible.
                </p>
                <p>
                  El segundo factor en importancia es el <strong>número de baños</strong> (8.1%), seguido por la <strong>posición relativa del piso</strong> (6.5%). Esto indica que además del tamaño, los compradores valoran la cantidad de servicios sanitarios y la ubicación vertical dentro del edificio. Las propiedades en pisos más altos tienden a tener mayor valor.
                </p>
                <p>
                  El <strong>modelo Random Forest</strong> alcanza una precisión de R² = 0.8763 (87.63%), superando significativamente a la Regresión Lineal (R² = 0.6138). Esto demuestra que las relaciones entre variables no son lineales y que el modelo captura interacciones complejas entre características.
                </p>
                <p>
                  La <strong>segmentación en clusters</strong> identifica tres perfiles de inversión distintos: Perfil Ejecutivo (propiedades de alto valor), Inversión Económica (propiedades compactas) e Inversión Familiar (propiedades medianas). Estos perfiles tienen características y rangos de precio claramente diferenciados.
                </p>
              </div>
            </div>
          </div>
        </Card>

        {/* Model Limitations */}
        <Card className="card-elegant mb-6 border-orange-500/30 bg-orange-500/5">
          <div className="space-y-6">
            <div>
              <h2 className="text-2xl font-bold mb-4 flex items-center gap-2">
                <AlertCircle className="w-6 h-6 text-orange-500" />
                Limitaciones del Modelo
              </h2>
              <div className="space-y-4">
                <div className="bg-card rounded-lg p-4 border border-border">
                  <h3 className="font-semibold mb-2">1. Dependencia de Datos Históricos</h3>
                  <p className="text-sm text-muted-foreground">
                    El modelo se entrena con datos históricos de un período específico. Si el mercado experimenta cambios drásticos (crisis económica, cambios regulatorios), las predicciones pueden volverse menos precisas. El modelo no captura tendencias futuras ni eventos inesperados.
                  </p>
                </div>

                <div className="bg-card rounded-lg p-4 border border-border">
                  <h3 className="font-semibold mb-2">2. Sesgo Geográfico</h3>
                  <p className="text-sm text-muted-foreground">
                    Aunque se incluye la variable de ubicación, el modelo puede tener sesgos hacia ciertas regiones o ciudades donde hay mayor concentración de datos. Las predicciones pueden ser menos confiables en áreas con pocos datos históricos.
                  </p>
                </div>

                <div className="bg-card rounded-lg p-4 border border-border">
                  <h3 className="font-semibold mb-2">3. Características Cualitativas No Capturadas</h3>
                  <p className="text-sm text-muted-foreground">
                    Variables como la calidad de construcción, el estado de conservación, la proximidad a servicios (escuelas, hospitales, transporte) y la seguridad del barrio no se incluyen explícitamente en el modelo. Estas características tienen impacto real en los precios.
                  </p>
                </div>

                <div className="bg-card rounded-lg p-4 border border-border">
                  <h3 className="font-semibold mb-2">4. Outliers y Propiedades Especiales</h3>
                  <p className="text-sm text-muted-foreground">
                    Propiedades con características únicas (mansiones, propiedades históricas, ubicaciones premium) pueden tener precios que no siguen los patrones generales. El modelo puede subestimar o sobrestimar estos casos extremos.
                  </p>
                </div>

                <div className="bg-card rounded-lg p-4 border border-border">
                  <h3 className="font-semibold mb-2">5. Datos Faltantes y Calidad</h3>
                  <p className="text-sm text-muted-foreground">
                    Aproximadamente el 43% de los datos tenían valores faltantes en variables como "Balcones" y "Estacionamientos". Se implementaron estrategias de imputación (asumir 0 para balcones, llenar con la moda para baños), pero esto puede introducir sesgos.
                  </p>
                </div>

                <div className="bg-card rounded-lg p-4 border border-border">
                  <h3 className="font-semibold mb-2">6. Contexto Temporal</h3>
                  <p className="text-sm text-muted-foreground">
                    El modelo no incluye variables temporales (año de venta, estacionalidad). Los precios inmobiliarios fluctúan con el tiempo, y el modelo proporciona predicciones basadas en patrones históricos promediados.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </Card>

        {/* Recommendations */}
        <Card className="card-elegant mb-6 border-accent/30 bg-accent/5">
          <div className="space-y-6">
            <div>
              <h2 className="text-2xl font-bold mb-4 flex items-center gap-2">
                <Database className="w-6 h-6 text-accent" />
                Datos Adicionales para Mejorar la Precisión
              </h2>
              <div className="space-y-3">
                <div className="bg-card rounded-lg p-4 border border-border">
                  <h3 className="font-semibold mb-2">Características Estructurales</h3>
                  <ul className="text-sm text-muted-foreground space-y-1 list-disc list-inside">
                    <li>Año de construcción y edad de la propiedad</li>
                    <li>Tipo de construcción (concreto, ladrillo, mixta)</li>
                    <li>Calidad de acabados (básica, estándar, premium)</li>
                    <li>Presencia de amenidades (piscina, gym, jardín)</li>
                  </ul>
                </div>

                <div className="bg-card rounded-lg p-4 border border-border">
                  <h3 className="font-semibold mb-2">Factores de Ubicación</h3>
                  <ul className="text-sm text-muted-foreground space-y-1 list-disc list-inside">
                    <li>Coordenadas GPS precisas</li>
                    <li>Distancia a centros comerciales, estaciones de transporte</li>
                    <li>Índices de seguridad y criminalidad del barrio</li>
                    <li>Calidad de escuelas cercanas</li>
                    <li>Acceso a servicios de salud</li>
                  </ul>
                </div>

                <div className="bg-card rounded-lg p-4 border border-border">
                  <h3 className="font-semibold mb-2">Variables Temporales</h3>
                  <ul className="text-sm text-muted-foreground space-y-1 list-disc list-inside">
                    <li>Fecha de venta (para capturar tendencias temporales)</li>
                    <li>Tiempo en el mercado antes de venta</li>
                    <li>Variaciones estacionales de precios</li>
                  </ul>
                </div>

                <div className="bg-card rounded-lg p-4 border border-border">
                  <h3 className="font-semibold mb-2">Datos de Mercado</h3>
                  <ul className="text-sm text-muted-foreground space-y-1 list-disc list-inside">
                    <li>Historial de precios de propiedades comparables</li>
                    <li>Tendencias de precios por zona</li>
                    <li>Indicadores económicos (inflación, tasas de interés)</li>
                    <li>Demanda y oferta en el mercado</li>
                  </ul>
                </div>

                <div className="bg-card rounded-lg p-4 border border-border">
                  <h3 className="font-semibold mb-2">Características de Diseño</h3>
                  <ul className="text-sm text-muted-foreground space-y-1 list-disc list-inside">
                    <li>Distribución de espacios (plano de la propiedad)</li>
                    <li>Iluminación natural y ventilación</li>
                    <li>Vistas (panorámicas, al mar, a la ciudad)</li>
                    <li>Acceso a áreas verdes</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </Card>

        {/* Conclusions */}
        <Card className="card-elegant">
          <div className="space-y-6">
            <div>
              <h2 className="text-2xl font-bold mb-4">Conclusiones</h2>
              <div className="space-y-4 text-muted-foreground leading-relaxed">
                <p>
                  El modelo Random Forest proporciona predicciones confiables con una precisión del 87.63%, siendo significativamente superior a los métodos lineales tradicionales. Es especialmente útil para obtener estimaciones rápidas de precios basadas en características estructurales básicas.
                </p>
                <p>
                  Sin embargo, para aplicaciones de alto valor (decisiones de inversión significativas, valuaciones profesionales), se recomienda complementar este modelo con análisis adicionales que incluyan factores cualitativos, contexto de mercado y datos geográficos más detallados.
                </p>
                <p>
                  La segmentación en tres perfiles de inversión es útil para identificar oportunidades de mercado y estrategias de inversión diferenciadas. Cada perfil tiene características y rangos de precio distintos que pueden guiar decisiones de compra-venta.
                </p>
              </div>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}
