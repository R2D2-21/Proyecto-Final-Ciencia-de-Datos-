import { useEffect, useState } from "react";
import { Card } from "@/components/ui/card";
import { Loader2 } from "lucide-react";
import { trpc } from "@/lib/trpc";
import ModelComparisonChart from "@/components/ModelComparisonChart";
import {
  BarChart,
  Bar,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from "recharts";

export default function Dashboard() {
  const [featureData, setFeatureData] = useState<any>(null);
  const [modelMetrics, setModelMetrics] = useState<any>(null);

  const featureQuery = trpc.ml.featureImportance.useQuery();
  const metricsQuery = trpc.ml.modelMetrics.useQuery();

  useEffect(() => {
    if (featureQuery.data) {
      const data = Object.entries(featureQuery.data).map(([name, value]) => ({
        name: name.replace(/_/g, " "),
        importance: value,
      }));
      setFeatureData(data);
    }
  }, [featureQuery.data]);

  useEffect(() => {
    if (metricsQuery.data) {
      setModelMetrics(metricsQuery.data);
    }
  }, [metricsQuery.data]);

  const COLORS = [
    "oklch(0.65 0.2 25)",
    "oklch(0.7 0.15 35)",
    "oklch(0.6 0.25 40)",
  ];

  return (
    <div className="min-h-screen section-spacing bg-gradient-to-br from-background via-background to-accent/5">
      <div className="container">
        {/* Header */}
        <div className="mb-12">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">
            Dashboard de Análisis
          </h1>
          <p className="text-lg text-muted-foreground">
            Visualización de correlaciones, importancia de variables y desempeño de modelos
          </p>
        </div>

        {/* Feature Importance */}
        <div className="grid md:grid-cols-2 gap-6 mb-6">
          <Card className="card-elegant">
            <div className="space-y-4">
              <h2 className="text-2xl font-bold">Importancia de Variables</h2>
              {featureQuery.isLoading ? (
                <div className="flex items-center justify-center h-80">
                  <Loader2 className="w-8 h-8 animate-spin text-accent" />
                </div>
              ) : featureData ? (
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={featureData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                    <XAxis
                      dataKey="name"
                      angle={-45}
                      textAnchor="end"
                      height={100}
                      tick={{ fontSize: 12 }}
                    />
                    <YAxis tick={{ fontSize: 12 }} />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: "var(--card)",
                        border: "1px solid var(--border)",
                        borderRadius: "8px",
                      }}
                      formatter={(value) => (value as number).toFixed(4)}
                    />
                    <Bar dataKey="importance" fill="var(--accent)" radius={[8, 8, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              ) : null}
              <p className="text-sm text-muted-foreground">
                El área de la propiedad es el factor más importante (72.3%) en la predicción de precios.
              </p>
            </div>
          </Card>

          {/* Model Comparison Chart */}
          <Card className="card-elegant">
            <div className="space-y-4">
              <h2 className="text-2xl font-bold">Gráfico Comparativo de Modelos</h2>
              {metricsQuery.isLoading ? (
                <div className="flex items-center justify-center h-80">
                  <Loader2 className="w-8 h-8 animate-spin text-accent" />
                </div>
              ) : modelMetrics ? (
                <ModelComparisonChart data={modelMetrics} />
              ) : null}
              <p className="text-sm text-muted-foreground">
                Comparación visual de MAE, RMSE y R² entre Regresión Lineal y Random Forest.
              </p>
            </div>
          </Card>

          {/* Model Comparison */}
          <Card className="card-elegant">
            <div className="space-y-4">
              <h2 className="text-2xl font-bold">Métricas Detalladas</h2>
              {metricsQuery.isLoading ? (
                <div className="flex items-center justify-center h-80">
                  <Loader2 className="w-8 h-8 animate-spin text-accent" />
                </div>
              ) : modelMetrics ? (
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    {/* Linear Regression */}
                    <div className="bg-accent/5 rounded-lg p-4 border border-accent/20">
                      <p className="text-sm font-semibold text-muted-foreground mb-3">
                        Regresión Lineal
                      </p>
                      <div className="space-y-2">
                        <div>
                          <p className="text-xs text-muted-foreground">MAE</p>
                          <p className="text-lg font-bold">
                            {(modelMetrics.linear_regression.MAE / 1000000).toFixed(2)}M
                          </p>
                        </div>
                        <div>
                          <p className="text-xs text-muted-foreground">RMSE</p>
                          <p className="text-lg font-bold">
                            {(modelMetrics.linear_regression.RMSE / 1000000).toFixed(2)}M
                          </p>
                        </div>
                        <div>
                          <p className="text-xs text-muted-foreground">R²</p>
                          <p className="text-lg font-bold text-accent">
                            {(modelMetrics.linear_regression.R2 * 100).toFixed(2)}%
                          </p>
                        </div>
                      </div>
                    </div>

                    {/* Random Forest */}
                    <div className="bg-accent/10 rounded-lg p-4 border border-accent/40">
                      <p className="text-sm font-semibold text-muted-foreground mb-3">
                        Random Forest ⭐
                      </p>
                      <div className="space-y-2">
                        <div>
                          <p className="text-xs text-muted-foreground">MAE</p>
                          <p className="text-lg font-bold">
                            {(modelMetrics.random_forest.MAE / 1000000).toFixed(2)}M
                          </p>
                        </div>
                        <div>
                          <p className="text-xs text-muted-foreground">RMSE</p>
                          <p className="text-lg font-bold">
                            {(modelMetrics.random_forest.RMSE / 1000000).toFixed(2)}M
                          </p>
                        </div>
                        <div>
                          <p className="text-xs text-muted-foreground">R²</p>
                          <p className="text-lg font-bold text-accent">
                            {(modelMetrics.random_forest.R2 * 100).toFixed(2)}%
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    Random Forest supera significativamente a Regresión Lineal con una mejora de 43.7% en R².
                  </p>
                </div>
              ) : null}
            </div>
          </Card>
        </div>

        {/* Metrics Table */}
        <Card className="card-elegant">
          <div className="space-y-4">
            <h2 className="text-2xl font-bold">Tabla de Métricas Detalladas</h2>
            {metricsQuery.isLoading ? (
              <div className="flex items-center justify-center h-40">
                <Loader2 className="w-8 h-8 animate-spin text-accent" />
              </div>
            ) : modelMetrics ? (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-border">
                      <th className="text-left py-3 px-4 font-semibold">Modelo</th>
                      <th className="text-right py-3 px-4 font-semibold">MAE</th>
                      <th className="text-right py-3 px-4 font-semibold">RMSE</th>
                      <th className="text-right py-3 px-4 font-semibold">R²</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr className="border-b border-border hover:bg-muted/50 transition-colors">
                      <td className="py-3 px-4 font-medium">Regresión Lineal</td>
                      <td className="text-right py-3 px-4">
                        ₹{(modelMetrics.linear_regression.MAE / 1000000).toFixed(2)}M
                      </td>
                      <td className="text-right py-3 px-4">
                        ₹{(modelMetrics.linear_regression.RMSE / 1000000).toFixed(2)}M
                      </td>
                      <td className="text-right py-3 px-4 font-semibold">
                        {(modelMetrics.linear_regression.R2 * 100).toFixed(2)}%
                      </td>
                    </tr>
                    <tr className="bg-accent/5 hover:bg-accent/10 transition-colors">
                      <td className="py-3 px-4 font-medium">Random Forest</td>
                      <td className="text-right py-3 px-4 font-semibold">
                        ₹{(modelMetrics.random_forest.MAE / 1000000).toFixed(2)}M
                      </td>
                      <td className="text-right py-3 px-4 font-semibold">
                        ₹{(modelMetrics.random_forest.RMSE / 1000000).toFixed(2)}M
                      </td>
                      <td className="text-right py-3 px-4 font-semibold text-accent">
                        {(modelMetrics.random_forest.R2 * 100).toFixed(2)}%
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            ) : null}
          </div>
        </Card>
      </div>
    </div>
  );
}
