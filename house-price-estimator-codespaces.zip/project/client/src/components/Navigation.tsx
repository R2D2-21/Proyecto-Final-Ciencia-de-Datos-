import { Link } from "wouter";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { getLoginUrl } from "@/const";

export default function Navigation() {
  const { user, logout, isAuthenticated } = useAuth();

  return (
    <nav className="sticky top-0 z-50 bg-card/95 backdrop-blur-md border-b border-border shadow-sm">
      <div className="container flex items-center justify-between h-16 md:h-20">
        {/* Logo */}
        <Link href="/">
          <span className="flex items-center gap-2 hover:opacity-80 transition-opacity cursor-pointer">
            <div className="w-8 h-8 bg-gradient-to-br from-accent to-orange-500 rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-lg">📊</span>
            </div>
            <span className="font-bold text-lg hidden sm:inline text-gradient">
              PropEstimate
            </span>
          </span>
        </Link>

        {/* Navigation Links */}
        <div className="hidden md:flex items-center gap-8">
          <Link href="/">
            <span className="text-sm font-medium hover:text-accent transition-colors cursor-pointer">
              Inicio
            </span>
          </Link>
          <Link href="/predictor">
            <span className="text-sm font-medium hover:text-accent transition-colors cursor-pointer">
              Estimador
            </span>
          </Link>
          <Link href="/dashboard">
            <span className="text-sm font-medium hover:text-accent transition-colors cursor-pointer">
              Análisis
            </span>
          </Link>
          <Link href="/report">
            <span className="text-sm font-medium hover:text-accent transition-colors cursor-pointer">
              Reporte
            </span>
          </Link>
        </div>

        {/* Auth Section */}
        <div className="flex items-center gap-4">
          {isAuthenticated ? (
            <div className="flex items-center gap-3">
              <span className="text-sm text-muted-foreground hidden sm:inline">
                {user?.name || user?.email}
              </span>
              <Button
                onClick={() => logout()}
                variant="outline"
                size="sm"
              >
                Salir
              </Button>
            </div>
          ) : (
            <a href={getLoginUrl()}>
              <Button size="sm">
                Ingresar
              </Button>
            </a>
          )}
        </div>
      </div>
    </nav>
  );
}
