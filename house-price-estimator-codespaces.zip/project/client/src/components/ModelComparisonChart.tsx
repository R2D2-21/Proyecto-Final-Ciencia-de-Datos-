import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";

interface ModelMetrics {
  linear_regression: {
    MAE: number;
    RMSE: number;
    R2: number;
  };
  random_forest: {
    MAE: number;
    RMSE: number;
    R2: number;
  };
}

interface ModelComparisonChartProps {
  data: ModelMetrics;
}

export default function ModelComparisonChart({ data }: ModelComparisonChartProps) {
  // Preparar datos para el gráfico
  const chartData = [
    {
      metric: "MAE (Millones)",
      "Regresión Lineal": data.linear_regression.MAE / 1000000,
      "Random Forest": data.random_forest.MAE / 1000000,
    },
    {
      metric: "RMSE (Millones)",
      "Regresión Lineal": data.linear_regression.RMSE / 1000000,
      "Random Forest": data.random_forest.RMSE / 1000000,
    },
    {
      metric: "R² (%)",
      "Regresión Lineal": data.linear_regression.R2 * 100,
      "Random Forest": data.random_forest.R2 * 100,
    },
  ];

  return (
    <ResponsiveContainer width="100%" height={300}>
      <BarChart data={chartData}>
        <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
        <XAxis dataKey="metric" tick={{ fontSize: 12 }} />
        <YAxis tick={{ fontSize: 12 }} />
        <Tooltip
          contentStyle={{
            backgroundColor: "var(--card)",
            border: "1px solid var(--border)",
            borderRadius: "8px",
          }}
          formatter={(value) => {
            if (typeof value === "number") {
              return value.toFixed(2);
            }
            return value;
          }}
        />
        <Legend />
        <Bar dataKey="Regresión Lineal" fill="oklch(0.7 0.15 35)" radius={[8, 8, 0, 0]} />
        <Bar dataKey="Random Forest" fill="var(--accent)" radius={[8, 8, 0, 0]} />
      </BarChart>
    </ResponsiveContainer>
  );
}
