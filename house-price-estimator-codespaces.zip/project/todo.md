# Project TODO - Estimador de Precios de Propiedades

## Backend & ML Integration
- [x] Integrar modelos ML (rf_model.joblib y kmeans_model.joblib) en el servidor
- [x] Crear endpoint `/api/trpc/predict` para predicción de precios
- [x] Crear endpoint `/api/trpc/clusterProfile` para análisis de segmentación
- [x] Crear endpoint `/api/trpc/modelMetrics` para métricas de evaluación
- [x] Crear endpoint `/api/trpc/featureImportance` para datos de EDA

## Frontend - Estructura Base
- [x] Diseñar paleta de colores sofisticada y elegante (naranja/rojo)
- [x] Configurar tipografía refinada con Google Fonts (Playfair Display + Poppins)
- [x] Crear layout principal con navegación elegante
- [x] Implementar componentes base (cards, buttons, inputs)

## Página de Estimación de Precios
- [x] Crear formulario interactivo con campos: área, baños, balcones, estacionamientos, BHK, piso relativo, lujo
- [x] Implementar validación de entrada
- [x] Conectar con endpoint de predicción
- [x] Mostrar resultado de precio estimado con formato elegante
- [x] Agregar indicador de confianza/rango de precios

## Dashboard de EDA
- [x] Mostrar importancia de variables según Random Forest (gráfico de barras)
- [x] Mostrar comparación de modelos (Linear Regression vs Random Forest)
- [x] Tabla detallada de métricas (MAE, RMSE, R²)
- [ ] Agregar heatmap de correlaciones (opcional)

## Visualización de Segmentación
- [x] Integración de clustering en predictor
- [x] Mostrar perfil de inversión (Perfil Familiar, Perfil Ejecutivo, Inversión Económica)
- [ ] Gráficos adicionales de características por cluster
- [ ] Tabla de estadísticas por perfil

## Reporte de Análisis Crítico
- [x] Sección de hallazgos principales (correlaciones más importantes)
- [x] Explicación de limitaciones del modelo
- [x] Datos adicionales que mejorarían la precisión
- [x] Análisis de sesgos y consideraciones

## Comparación de Modelos
- [x] Tabla comparativa: Linear Regression vs Random Forest
- [x] Mostrar MAE, RMSE, R² para ambos modelos
- [x] Gráfico visual de comparación de métricas

## Refinamiento Visual & Pruebas
- [ ] Pruebas de responsividad en diferentes dispositivos
- [ ] Optimización de rendimiento
- [ ] Revisión de accesibilidad
- [ ] Testing de funcionalidades críticas
